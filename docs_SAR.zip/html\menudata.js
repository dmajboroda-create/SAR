/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Титульна сторінка",url:"index.html"},
{text:"Topics",url:"topics.html"},
{text:"Класи",url:"annotated.html",children:[
{text:"Класи",url:"annotated.html"},
{text:"Алфавітний покажчик класів",url:"classes.html"},
{text:"Ієрархія класів",url:"hierarchy.html"},
{text:"Елементи класів",url:"functions.html",children:[
{text:"Всі",url:"functions.html"},
{text:"Функції",url:"functions_func.html"},
{text:"Змінні",url:"functions_vars.html"}]}]},
{text:"Файли",url:"files.html",children:[
{text:"Файли",url:"files.html"},
{text:"Елементи файлу",url:"globals.html",children:[
{text:"Всі",url:"globals.html",children:[
{text:"d",url:"globals.html#index_d"},
{text:"m",url:"globals.html#index_m"},
{text:"r",url:"globals.html#index_r"},
{text:"s",url:"globals.html#index_s"},
{text:"t",url:"globals.html#index_t"}]},
{text:"Функції",url:"globals_func.html"},
{text:"Змінні",url:"globals_vars.html"},
{text:"Визначення типів",url:"globals_type.html"}]}]},
{text:"Приклади",url:"examples.html"}]}
